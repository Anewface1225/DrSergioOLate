"use client";

import { useEffect } from "react";

export default function ClientBody({
  children,
}: {
  children: React.ReactNode;
}) {
  // Remove any extension-added classes during hydration
  useEffect(() => {
    // This runs only on the client after hydration
    // Clean up any browser extension classes that might cause hydration mismatches
    const cleanupClasses = () => {
      // Remove common extension classes
      document.body.className = document.body.className
        .split(' ')
        .filter(cls => !cls.startsWith('__'))
        .filter(cls => !cls.includes('extension'))
        .filter(cls => !cls.includes('plugin'))
        .join(' ');

      // Ensure our classes are present
      if (!document.body.className.includes('antialiased')) {
        document.body.classList.add('antialiased');
      }
    };

    // Run cleanup immediately
    cleanupClasses();

    // Also run after a short delay to catch any late-loading extensions
    const timer = setTimeout(cleanupClasses, 100);

    return () => clearTimeout(timer);
  }, []);

  return <>{children}</>;
}
