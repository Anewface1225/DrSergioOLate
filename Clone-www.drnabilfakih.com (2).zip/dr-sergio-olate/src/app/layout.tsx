import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import ClientBody from "./ClientBody";

const inter = Inter({
  subsets: ["latin"],
  display: 'swap',
  preload: true
});

export const metadata: Metadata = {
  title: "Dr. Sergio Olate - Especialista en Reconstrucción Maxilofacial",
  description:
    "Dr. Sergio Olate, especialista en reconstrucción maxilofacial con asistencia digital. Cirugía reconstructiva avanzada para devolver función y estética facial con los más altos estándares internacionales.",
  keywords: [
    "cirugía maxilofacial",
    "reconstrucción facial",
    "Dr. Sergio Olate",
    "cirugía reconstructiva",
    "asistencia digital",
    "estética facial",
    "cirujano maxilofacial",
    "Chile",
    "Temuco",
    "planificación 3D",
    "microcirugía",
    "Universidad de La Frontera",
    "UFRO",
    "biomarcadores quirúrgicos",
    "realidad virtual médica"
  ],
  authors: [{ name: "Dr. Sergio Olate", url: "https://same-w7qehzskhqv-latest.netlify.app" }],
  creator: "Dr. Sergio Olate",
  publisher: "Dr. Sergio Olate",
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  openGraph: {
    title: "Dr. Sergio Olate - Especialista en Reconstrucción Maxilofacial",
    description:
      "Especialista en cirugía reconstructiva con tecnología de vanguardia para devolver la función y estética facial.",
    url: "https://same-w7qehzskhqv-latest.netlify.app",
    siteName: "Dr. Sergio Olate",
    type: "website",
    locale: "es_ES",
    images: [
      {
        url: "https://same-w7qehzskhqv-latest.netlify.app/images/dr-sergio-olate-profesional.jpg",
        width: 900,
        height: 600,
        alt: "Dr. Sergio Olate - Especialista en Reconstrucción Maxilofacial",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Dr. Sergio Olate - Especialista en Reconstrucción Maxilofacial",
    description: "Cirugía reconstructiva avanzada con tecnología de vanguardia",
    images: ["https://same-w7qehzskhqv-latest.netlify.app/images/dr-sergio-olate-profesional.jpg"],
  },
  viewport: {
    width: 'device-width',
    initialScale: 1,
    maximumScale: 5,
  },
  themeColor: [
    { media: '(prefers-color-scheme: light)', color: '#ffffff' },
    { media: '(prefers-color-scheme: dark)', color: '#000000' }
  ],
  category: 'healthcare',
  classification: 'medical specialist',
  applicationName: 'Dr. Sergio Olate - Cirugía Maxilofacial',
  referrer: 'origin-when-cross-origin',
  colorScheme: 'dark light',
  verification: {
    google: 'google-verification-code',
    other: {
      'facebook-domain-verification': 'facebook-verification-code',
    },
  },
  alternates: {
    canonical: 'https://same-w7qehzskhqv-latest.netlify.app',
    languages: {
      'es-ES': 'https://same-w7qehzskhqv-latest.netlify.app',
      'en-US': 'https://same-w7qehzskhqv-latest.netlify.app/en',
    },
  },
  icons: {
    icon: '/favicon.ico',
    shortcut: '/favicon-16x16.png',
    apple: '/apple-touch-icon.png',
    other: {
      rel: 'apple-touch-icon-precomposed',
      url: '/apple-touch-icon-precomposed.png',
    },
  },
  manifest: '/manifest.json',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="es" className="scroll-smooth">
      <head>
        <link rel="canonical" href="https://same-w7qehzskhqv-latest.netlify.app" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link rel="dns-prefetch" href="//fonts.googleapis.com" />
        <link rel="dns-prefetch" href="//fonts.gstatic.com" />
        <meta name="format-detection" content="telephone=yes" />
        <meta name="geo.region" content="CL-AR" />
        <meta name="geo.placename" content="Temuco, Chile" />
        <meta name="geo.position" content="-38.7359;-72.5904" />
        <meta name="ICBM" content="-38.7359, -72.5904" />
        <meta name="mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
        <meta name="msapplication-TileColor" content="#ef4444" />
        <meta name="msapplication-config" content="/browserconfig.xml" />
        <meta httpEquiv="Content-Security-Policy" content="upgrade-insecure-requests" />
        <meta name="theme-color" content="#ef4444" />

        {/* Preload critical resources */}
        <link
          rel="preload"
          href="/images/dr-sergio-olate-profesional.jpg"
          as="image"
          type="image/jpeg"
        />

        {/* Schema.org JSON-LD for Healthcare Provider */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@graph": [
                {
                  "@type": "Person",
                  "@id": "https://same-w7qehzskhqv-latest.netlify.app/#person",
                  "name": "Dr. Sergio Olate",
                  "givenName": "Sergio",
                  "familyName": "Olate",
                  "jobTitle": "Especialista en Reconstrucción Maxilofacial",
                  "description": "Especialista en cirugía reconstructiva con tecnología de vanguardia para devolver la función y estética facial",
                  "image": {
                    "@type": "ImageObject",
                    "url": "https://same-w7qehzskhqv-latest.netlify.app/images/dr-sergio-olate-profesional.jpg",
                    "width": 900,
                    "height": 600
                  },
                  "worksFor": {
                    "@type": "Organization",
                    "name": "Universidad de La Frontera",
                    "department": "Facultad de Odontología"
                  },
                  "alumniOf": {
                    "@type": "EducationalOrganization",
                    "name": "Universidad de La Frontera"
                  },
                  "address": {
                    "@type": "PostalAddress",
                    "streetAddress": "Francisco Contreras 1225",
                    "addressLocality": "Temuco",
                    "addressRegion": "Araucanía",
                    "postalCode": "4810556",
                    "addressCountry": "CL"
                  },
                  "telephone": "+56 9 47441572",
                  "email": "contactoanewface@gmail.com",
                  "url": "https://same-w7qehzskhqv-latest.netlify.app",
                  "sameAs": [
                    "https://odontologia.ufro.cl",
                    "https://alumni.ufro.cl"
                  ],
                  "knowsAbout": [
                    "Cirugía Maxilofacial",
                    "Reconstrucción Facial",
                    "Planificación Digital 3D",
                    "Microcirugía",
                    "Biomarcadores Quirúrgicos",
                    "Realidad Virtual Médica",
                    "Machine Learning en Medicina"
                  ],
                  "hasCredential": [
                    {
                      "@type": "EducationalOccupationalCredential",
                      "name": "Especialista en Cirugía Maxilofacial",
                      "credentialCategory": "Especialización Médica",
                      "educationalLevel": "Posgrado",
                      "recognizedBy": {
                        "@type": "Organization",
                        "name": "Universidad de La Frontera"
                      }
                    }
                  ]
                },
                {
                  "@type": "MedicalOrganization",
                  "@id": "https://same-w7qehzskhqv-latest.netlify.app/#organization",
                  "name": "Dr. Sergio Olate - Cirugía Maxilofacial",
                  "description": "Clínica especializada en reconstrucción maxilofacial con asistencia digital",
                  "medicalSpecialty": "Cirugía Maxilofacial",
                  "address": {
                    "@type": "PostalAddress",
                    "streetAddress": "Av. Francisco Salazar 01145",
                    "addressLocality": "Temuco",
                    "addressRegion": "Araucanía",
                    "postalCode": "4811230",
                    "addressCountry": "CL"
                  },
                  "telephone": "+56 45 325 4000",
                  "email": "sergio.olate@medico.cl",
                  "url": "https://same-w7qehzskhqv-latest.netlify.app",
                  "hasOfferCatalog": {
                    "@type": "OfferCatalog",
                    "name": "Servicios de Cirugía Maxilofacial",
                    "itemListElement": [
                      {
                        "@type": "Offer",
                        "itemOffered": {
                          "@type": "MedicalProcedure",
                          "name": "Reconstrucción Maxilofacial",
                          "medicalSpecialty": "Cirugía Maxilofacial"
                        }
                      },
                      {
                        "@type": "Offer",
                        "itemOffered": {
                          "@type": "MedicalProcedure",
                          "name": "Planificación Digital 3D",
                          "medicalSpecialty": "Cirugía Maxilofacial"
                        }
                      }
                    ]
                  },
                  "openingHours": [
                    "Mo-Fr 09:30-18:30",
                    "Sa Cerrado"
                  ]
                },
                {
                  "@type": "WebSite",
                  "@id": "https://same-w7qehzskhqv-latest.netlify.app/#website",
                  "url": "https://same-w7qehzskhqv-latest.netlify.app",
                  "name": "Dr. Sergio Olate - Especialista en Reconstrucción Maxilofacial",
                  "description": "Sitio web oficial del Dr. Sergio Olate, especialista en reconstrucción maxilofacial",
                  "publisher": {
                    "@id": "https://same-w7qehzskhqv-latest.netlify.app/#person"
                  },
                  "potentialAction": {
                    "@type": "SearchAction",
                    "target": "https://same-w7qehzskhqv-latest.netlify.app/?q={search_term_string}",
                    "query-input": "required name=search_term_string"
                  },
                  "inLanguage": "es-ES"
                }
              ]
            })
          }}
        />
      </head>
      <body className={`${inter.className} smooth-scroll`}>
        <noscript>
          <div style={{
            position: 'fixed',
            top: 0,
            left: 0,
            width: '100%',
            backgroundColor: '#ef4444',
            color: 'white',
            textAlign: 'center',
            padding: '10px',
            zIndex: 10000
          }}>
            Para una mejor experiencia, habilite JavaScript en su navegador.
          </div>
        </noscript>
        <ClientBody>
          {children}
        </ClientBody>
      </body>
    </html>
  );
}
