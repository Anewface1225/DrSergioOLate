"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Phone, Mail, MapPin, Calendar, Award, Users, Stethoscope, Brain, Microscope, Monitor, Menu, Star, Quote, ArrowUp, BookOpen, FileText, ExternalLink } from "lucide-react";
import { useState, useEffect } from "react";
import Image from "next/image";

export default function Home() {
  const [showScrollTop, setShowScrollTop] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 300);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-black to-slate-900">
      {/* Header */}
      <header className="bg-black border-b border-slate-800 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-4">
              <div className="text-2xl font-bold text-white">
                Dr. <span className="text-red-500">Sergio Olate</span>
              </div>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex space-x-8">
              <button onClick={() => scrollToSection('inicio')} className="text-slate-300 hover:text-red-500 transition-colors">Inicio</button>
              <button onClick={() => scrollToSection('sobre')} className="text-slate-300 hover:text-red-500 transition-colors">Sobre Dr. Olate</button>
              <button onClick={() => scrollToSection('certificaciones')} className="text-slate-300 hover:text-red-500 transition-colors">Certificaciones</button>
              <button onClick={() => scrollToSection('publicaciones')} className="text-slate-300 hover:text-red-500 transition-colors">Publicaciones</button>
              <button onClick={() => scrollToSection('testimonios')} className="text-slate-300 hover:text-red-500 transition-colors">Testimonios</button>
              <button onClick={() => scrollToSection('contacto')} className="text-slate-300 hover:text-red-500 transition-colors">Contacto</button>
            </nav>

            <div className="flex items-center space-x-4">
              <Button className="bg-red-500 hover:bg-red-600 text-white hidden sm:flex" onClick={() => scrollToSection('contacto')}>
                <Calendar className="w-4 h-4 mr-2" />
                Agendar Cita
              </Button>

              {/* Mobile Menu */}
              <Sheet>
                <SheetTrigger asChild>
                  <Button variant="outline" size="icon" className="md:hidden">
                    <Menu className="h-4 w-4" />
                  </Button>
                </SheetTrigger>
                <SheetContent>
                  <SheetHeader>
                    <SheetTitle>
                      Dr. <span className="text-red-500">Sergio Olate</span>
                    </SheetTitle>
                    <SheetDescription>
                      Especialista en Reconstrucción Maxilofacial
                    </SheetDescription>
                  </SheetHeader>
                  <div className="grid gap-4 py-4">
                    <Button variant="ghost" className="justify-start" onClick={() => scrollToSection('inicio')}>
                      Inicio
                    </Button>
                    <Button variant="ghost" className="justify-start" onClick={() => scrollToSection('sobre')}>
                      Sobre Dr. Olate
                    </Button>
                    <Button variant="ghost" className="justify-start" onClick={() => scrollToSection('certificaciones')}>
                      Certificaciones
                    </Button>
                    <Button variant="ghost" className="justify-start" onClick={() => scrollToSection('publicaciones')}>
                      Publicaciones
                    </Button>
                    <Button variant="ghost" className="justify-start" onClick={() => scrollToSection('testimonios')}>
                      Testimonios
                    </Button>
                    <Button variant="ghost" className="justify-start" onClick={() => scrollToSection('contacto')}>
                      Contacto
                    </Button>
                    <Button className="bg-red-500 hover:bg-red-600 text-white mt-4" onClick={() => scrollToSection('contacto')}>
                      <Calendar className="w-4 h-4 mr-2" />
                      Agendar Cita
                    </Button>
                  </div>
                </SheetContent>
              </Sheet>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section id="inicio" className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <Badge className="mb-4 bg-red-100 text-red-700 hover:bg-red-200">
                Especialista en Reconstrucción Maxilofacial
              </Badge>
              <h1 className="text-5xl font-bold text-white leading-tight mb-6">
                Dr. <span className="text-red-500">Sergio Olate</span>
              </h1>
              <p className="text-xl text-slate-300 mb-4">
                Asistencia Digital en Reconstrucción Maxilofacial
              </p>
              <p className="text-lg text-slate-400 mb-8 leading-relaxed">
                Especialista en cirugía reconstructiva con tecnología de vanguardia para devolver la
                función y estética facial con los más altos estándares internacionales.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" className="bg-red-500 hover:bg-red-600 text-white" onClick={() => scrollToSection('contacto')}>
                  <Calendar className="w-5 h-5 mr-2" />
                  Consulta Especializada
                </Button>
                <Button size="lg" variant="outline" className="border-slate-300 hover:bg-slate-50" onClick={() => scrollToSection('contacto')}>
                  <Phone className="w-5 h-5 mr-2" />
                  Contactar Ahora
                </Button>
              </div>
              <div className="mt-8 text-sm text-slate-400">
                <p className="font-semibold">CIRUGÍA MAXILOFACIAL • TECNOLOGÍA DIGITAL • EXCELENCIA MÉDICA</p>
              </div>
            </div>
            <div className="relative">
              <div className="aspect-[4/5] rounded-2xl overflow-hidden shadow-2xl">
                <Image
                  src="/images/dr-sergio-olate-profesional.jpg"
                  alt="Dr. Sergio Olate - Especialista en Reconstrucción Maxilofacial"
                  width={600}
                  height={750}
                  className="w-full h-full object-cover"
                  priority
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="sobre" className="py-20 px-4 sm:px-6 lg:px-8 bg-slate-800">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold text-white mb-6">
                Sobre Dr. Sergio Olate
              </h2>
              <p className="text-lg text-slate-300 mb-6 leading-relaxed">
                Con más de 15 años de experiencia en cirugía maxilofacial, el Dr. Sergio Olate es reconocido
                internacionalmente por su innovador enfoque en la reconstrucción facial asistida por tecnología digital.
              </p>
              <div className="space-y-4">
                <div className="flex items-start gap-4">
                  <Award className="w-6 h-6 text-red-500 mt-1 flex-shrink-0" />
                  <div>
                    <h3 className="text-white font-semibold">Formación Académica</h3>
                    <p className="text-slate-300">Especialista en Cirugía Maxilofacial, Universidad de La Frontera</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <Monitor className="w-6 h-6 text-red-500 mt-1 flex-shrink-0" />
                  <div>
                    <h3 className="text-white font-semibold">Tecnología Avanzada</h3>
                    <p className="text-slate-300">Pionero en planificación quirúrgica 3D y cirugía asistida por computador</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <Users className="w-6 h-6 text-red-500 mt-1 flex-shrink-0" />
                  <div>
                    <h3 className="text-white font-semibold">Enfoque Personalizado</h3>
                    <p className="text-slate-300">Cada tratamiento se diseña específicamente para las necesidades del paciente</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="relative">
              <div className="aspect-[4/3] rounded-2xl overflow-hidden shadow-2xl">
                <Image
                  src="/images/dr-sergio-olate-consulta.jpg"
                  alt="Dr. Sergio Olate en su consulta médica"
                  width={600}
                  height={450}
                  className="w-full h-full object-cover"
                  loading="lazy"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Certifications and Awards Section */}
      <section id="certificaciones" className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <Badge className="mb-4 bg-red-100 text-red-700 hover:bg-red-200">
              Reconocimientos Profesionales
            </Badge>
            <h2 className="text-4xl font-bold text-white mb-6">
              Certificaciones y Premios
            </h2>
            <p className="text-xl text-slate-300 max-w-3xl mx-auto">
              Reconocimientos internacionales que avalan la excelencia académica y profesional del Dr. Sergio Olate
            </p>
          </div>

          {/* Professional Certifications */}
          <div className="mb-16">
            <h3 className="text-2xl font-bold text-white mb-8 text-center">Certificaciones Profesionales</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="certificate-badge group">
                <Card className="bg-gradient-to-br from-blue-900 to-blue-800 border-blue-600 hover:border-blue-400 transition-all duration-500 hover:scale-110 hover:shadow-2xl cursor-pointer">
                  <CardHeader className="text-center">
                    <div className="w-16 h-16 mx-auto mb-4 bg-blue-500 rounded-full flex items-center justify-center group-hover:animate-pulse">
                      <Stethoscope className="w-8 h-8 text-white" />
                    </div>
                    <CardTitle className="text-white text-lg">Especialista CMF</CardTitle>
                  </CardHeader>
                  <CardContent className="text-center">
                    <p className="text-blue-200 text-sm mb-2">Universidad de La Frontera</p>
                    <Badge variant="outline" className="text-blue-300 border-blue-300">2008</Badge>
                  </CardContent>
                </Card>
              </div>

              <div className="certificate-badge group">
                <Card className="bg-gradient-to-br from-green-900 to-green-800 border-green-600 hover:border-green-400 transition-all duration-500 hover:scale-110 hover:shadow-2xl cursor-pointer">
                  <CardHeader className="text-center">
                    <div className="w-16 h-16 mx-auto mb-4 bg-green-500 rounded-full flex items-center justify-center group-hover:animate-pulse">
                      <Brain className="w-8 h-8 text-white" />
                    </div>
                    <CardTitle className="text-white text-lg">Fellow IAOMS</CardTitle>
                  </CardHeader>
                  <CardContent className="text-center">
                    <p className="text-green-200 text-sm mb-2">International Association</p>
                    <Badge variant="outline" className="text-green-300 border-green-300">2015</Badge>
                  </CardContent>
                </Card>
              </div>

              <div className="certificate-badge group">
                <Card className="bg-gradient-to-br from-purple-900 to-purple-800 border-purple-600 hover:border-purple-400 transition-all duration-500 hover:scale-110 hover:shadow-2xl cursor-pointer">
                  <CardHeader className="text-center">
                    <div className="w-16 h-16 mx-auto mb-4 bg-purple-500 rounded-full flex items-center justify-center group-hover:animate-pulse">
                      <Microscope className="w-8 h-8 text-white" />
                    </div>
                    <CardTitle className="text-white text-lg">PhD Biomedical</CardTitle>
                  </CardHeader>
                  <CardContent className="text-center">
                    <p className="text-purple-200 text-sm mb-2">Universidad de Chile</p>
                    <Badge variant="outline" className="text-purple-300 border-purple-300">2012</Badge>
                  </CardContent>
                </Card>
              </div>

              <div className="certificate-badge group">
                <Card className="bg-gradient-to-br from-orange-900 to-orange-800 border-orange-600 hover:border-orange-400 transition-all duration-500 hover:scale-110 hover:shadow-2xl cursor-pointer">
                  <CardHeader className="text-center">
                    <div className="w-16 h-16 mx-auto mb-4 bg-orange-500 rounded-full flex items-center justify-center group-hover:animate-pulse">
                      <Monitor className="w-8 h-8 text-white" />
                    </div>
                    <CardTitle className="text-white text-lg">Digital Surgery</CardTitle>
                  </CardHeader>
                  <CardContent className="text-center">
                    <p className="text-orange-200 text-sm mb-2">Advanced Certification</p>
                    <Badge variant="outline" className="text-orange-300 border-orange-300">2018</Badge>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>

          {/* Awards and Recognition */}
          <div className="mb-16">
            <h3 className="text-2xl font-bold text-white mb-8 text-center">Premios y Reconocimientos</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="award-badge group">
                <Card className="bg-gradient-to-br from-yellow-900 to-amber-800 border-yellow-600 hover:border-yellow-400 transition-all duration-500 hover:scale-105 hover:shadow-2xl cursor-pointer">
                  <CardHeader className="text-center">
                    <div className="w-20 h-20 mx-auto mb-4 bg-gradient-to-br from-yellow-400 to-amber-500 rounded-full flex items-center justify-center group-hover:rotate-12 transition-transform duration-500">
                      <Award className="w-10 h-10 text-yellow-900" />
                    </div>
                    <CardTitle className="text-white text-xl">Mejor Investigador</CardTitle>
                  </CardHeader>
                  <CardContent className="text-center">
                    <p className="text-yellow-200 mb-3">Premio Nacional de Investigación en Cirugía Maxilofacial</p>
                    <Badge variant="outline" className="text-yellow-300 border-yellow-300">2021</Badge>
                    <p className="text-yellow-300 text-sm mt-2">Sociedad Chilena de Cirugía</p>
                  </CardContent>
                </Card>
              </div>

              <div className="award-badge group">
                <Card className="bg-gradient-to-br from-red-900 to-rose-800 border-red-600 hover:border-red-400 transition-all duration-500 hover:scale-105 hover:shadow-2xl cursor-pointer">
                  <CardHeader className="text-center">
                    <div className="w-20 h-20 mx-auto mb-4 bg-gradient-to-br from-red-400 to-rose-500 rounded-full flex items-center justify-center group-hover:rotate-12 transition-transform duration-500">
                      <Star className="w-10 h-10 text-red-900 fill-current" />
                    </div>
                    <CardTitle className="text-white text-xl">Excellence Award</CardTitle>
                  </CardHeader>
                  <CardContent className="text-center">
                    <p className="text-red-200 mb-3">International Excellence in Digital Surgery</p>
                    <Badge variant="outline" className="text-red-300 border-red-300">2022</Badge>
                    <p className="text-red-300 text-sm mt-2">IAOMS Global Conference</p>
                  </CardContent>
                </Card>
              </div>

              <div className="award-badge group">
                <Card className="bg-gradient-to-br from-indigo-900 to-blue-800 border-indigo-600 hover:border-indigo-400 transition-all duration-500 hover:scale-105 hover:shadow-2xl cursor-pointer">
                  <CardHeader className="text-center">
                    <div className="w-20 h-20 mx-auto mb-4 bg-gradient-to-br from-indigo-400 to-blue-500 rounded-full flex items-center justify-center group-hover:rotate-12 transition-transform duration-500">
                      <BookOpen className="w-10 h-10 text-indigo-900" />
                    </div>
                    <CardTitle className="text-white text-xl">Mejor Publicación</CardTitle>
                  </CardHeader>
                  <CardContent className="text-center">
                    <p className="text-indigo-200 mb-3">Artículo Más Citado en Machine Learning Médico</p>
                    <Badge variant="outline" className="text-indigo-300 border-indigo-300">2023</Badge>
                    <p className="text-indigo-300 text-sm mt-2">Journal Impact Award</p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>

          {/* Professional Memberships */}
          <div>
            <h3 className="text-2xl font-bold text-white mb-8 text-center">Membresías Profesionales</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
              <div className="membership-badge group">
                <Card className="bg-slate-800 border-slate-600 hover:border-red-500 transition-all duration-300 hover:scale-105 cursor-pointer">
                  <CardContent className="p-4 text-center">
                    <div className="w-12 h-12 mx-auto mb-2 bg-red-500 rounded-full flex items-center justify-center group-hover:animate-bounce">
                      <Users className="w-6 h-6 text-white" />
                    </div>
                    <p className="text-white text-xs font-semibold">IAOMS</p>
                    <p className="text-slate-400 text-xs">Member</p>
                  </CardContent>
                </Card>
              </div>

              <div className="membership-badge group">
                <Card className="bg-slate-800 border-slate-600 hover:border-red-500 transition-all duration-300 hover:scale-105 cursor-pointer">
                  <CardContent className="p-4 text-center">
                    <div className="w-12 h-12 mx-auto mb-2 bg-blue-500 rounded-full flex items-center justify-center group-hover:animate-bounce">
                      <Stethoscope className="w-6 h-6 text-white" />
                    </div>
                    <p className="text-white text-xs font-semibold">CONACEM</p>
                    <p className="text-slate-400 text-xs">Fellow</p>
                  </CardContent>
                </Card>
              </div>

              <div className="membership-badge group">
                <Card className="bg-slate-800 border-slate-600 hover:border-red-500 transition-all duration-300 hover:scale-105 cursor-pointer">
                  <CardContent className="p-4 text-center">
                    <div className="w-12 h-12 mx-auto mb-2 bg-green-500 rounded-full flex items-center justify-center group-hover:animate-bounce">
                      <Brain className="w-6 h-6 text-white" />
                    </div>
                    <p className="text-white text-xs font-semibold">ASMS</p>
                    <p className="text-slate-400 text-xs">Board</p>
                  </CardContent>
                </Card>
              </div>

              <div className="membership-badge group">
                <Card className="bg-slate-800 border-slate-600 hover:border-red-500 transition-all duration-300 hover:scale-105 cursor-pointer">
                  <CardContent className="p-4 text-center">
                    <div className="w-12 h-12 mx-auto mb-2 bg-purple-500 rounded-full flex items-center justify-center group-hover:animate-bounce">
                      <Monitor className="w-6 h-6 text-white" />
                    </div>
                    <p className="text-white text-xs font-semibold">ISCMF</p>
                    <p className="text-slate-400 text-xs">Active</p>
                  </CardContent>
                </Card>
              </div>

              <div className="membership-badge group">
                <Card className="bg-slate-800 border-slate-600 hover:border-red-500 transition-all duration-300 hover:scale-105 cursor-pointer">
                  <CardContent className="p-4 text-center">
                    <div className="w-12 h-12 mx-auto mb-2 bg-orange-500 rounded-full flex items-center justify-center group-hover:animate-bounce">
                      <Award className="w-6 h-6 text-white" />
                    </div>
                    <p className="text-white text-xs font-semibold">SBCMF</p>
                    <p className="text-slate-400 text-xs">Honorary</p>
                  </CardContent>
                </Card>
              </div>

              <div className="membership-badge group">
                <Card className="bg-slate-800 border-slate-600 hover:border-red-500 transition-all duration-300 hover:scale-105 cursor-pointer">
                  <CardContent className="p-4 text-center">
                    <div className="w-12 h-12 mx-auto mb-2 bg-teal-500 rounded-full flex items-center justify-center group-hover:animate-bounce">
                      <Microscope className="w-6 h-6 text-white" />
                    </div>
                    <p className="text-white text-xs font-semibold">ISAPS</p>
                    <p className="text-slate-400 text-xs">Associate</p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Publications Section */}
      <section id="publicaciones" className="py-20 px-4 sm:px-6 lg:px-8 bg-slate-800">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <Badge className="mb-4 bg-red-100 text-red-700 hover:bg-red-200">
              Investigación Académica
            </Badge>
            <h2 className="text-4xl font-bold text-white mb-6">
              Publicaciones Científicas
            </h2>
            <p className="text-xl text-slate-300 max-w-3xl mx-auto">
              Contribuciones académicas en el campo de la reconstrucción maxilofacial y asistencia digital en cirugía
            </p>
          </div>

          {/* Featured Publications with animations */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
            <Card className="publication-card bg-gradient-to-br from-slate-800 to-slate-900 border-slate-700 hover:border-red-500 transition-all duration-500 hover:scale-105 hover:shadow-2xl">
              <CardHeader>
                <div className="flex items-center gap-2 mb-2">
                  <BookOpen className="w-5 h-5 text-red-500" />
                  <Badge variant="outline" className="text-red-500 border-red-500">
                    Artículo Principal
                  </Badge>
                </div>
                <CardTitle className="text-white text-xl">
                  Digital Workflow in Maxillofacial Reconstruction: A Comprehensive Approach
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-300 text-sm mb-4">
                  Comprehensive analysis of digital workflow implementation in complex maxillofacial reconstruction cases, showing significant improvements in surgical outcomes and patient satisfaction.
                </p>
                <div className="flex flex-wrap gap-2 mb-4">
                  <Badge variant="secondary" className="text-xs">Digital Surgery</Badge>
                  <Badge variant="secondary" className="text-xs">3D Planning</Badge>
                  <Badge variant="secondary" className="text-xs">Q1 Journal</Badge>
                  <Badge variant="secondary" className="text-xs">Impact Factor: 3.2</Badge>
                </div>
                <div className="flex items-center justify-between text-sm text-slate-400">
                  <span>Journal of Oral and Maxillofacial Surgery • 2024</span>
                  <Button variant="ghost" size="sm" className="text-red-500 hover:text-red-400">
                    <ExternalLink className="w-4 h-4 mr-1" />
                    DOI: 10.1016/j.joms.2024.01.015
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card className="publication-card bg-gradient-to-br from-slate-800 to-slate-900 border-slate-700 hover:border-red-500 transition-all duration-500 hover:scale-105 hover:shadow-2xl">
              <CardHeader>
                <div className="flex items-center gap-2 mb-2">
                  <Microscope className="w-5 h-5 text-red-500" />
                  <Badge variant="outline" className="text-red-500 border-red-500">
                    Investigación Original
                  </Badge>
                </div>
                <CardTitle className="text-white text-xl">
                  Machine Learning Applications in Facial Reconstruction Planning
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-300 text-sm mb-4">
                  Novel application of machine learning algorithms to predict surgical outcomes and optimize treatment planning in facial reconstruction surgery.
                </p>
                <div className="flex flex-wrap gap-2 mb-4">
                  <Badge variant="secondary" className="text-xs">Machine Learning</Badge>
                  <Badge variant="secondary" className="text-xs">Predictive Models</Badge>
                  <Badge variant="secondary" className="text-xs">Q2 Journal</Badge>
                  <Badge variant="secondary" className="text-xs">Impact Factor: 2.8</Badge>
                </div>
                <div className="flex items-center justify-between text-sm text-slate-400">
                  <span>Computer Methods in Surgery • 2024</span>
                  <Button variant="ghost" size="sm" className="text-red-500 hover:text-red-400">
                    <ExternalLink className="w-4 h-4 mr-1" />
                    DOI: 10.1007/s11548-024-02987
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Research Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center mb-16">
            <div className="p-6 bg-slate-900 rounded-lg border border-slate-700">
              <div className="text-4xl font-bold text-red-500 mb-2">25+</div>
              <div className="text-slate-300 text-sm">Publicaciones Indexadas</div>
            </div>
            <div className="p-6 bg-slate-900 rounded-lg border border-slate-700">
              <div className="text-4xl font-bold text-red-500 mb-2">12</div>
              <div className="text-slate-300 text-sm">Revistas Q1/Q2</div>
            </div>
            <div className="p-6 bg-slate-900 rounded-lg border border-slate-700">
              <div className="text-4xl font-bold text-red-500 mb-2">450+</div>
              <div className="text-slate-300 text-sm">Citaciones Totales</div>
            </div>
            <div className="p-6 bg-slate-900 rounded-lg border border-slate-700">
              <div className="text-4xl font-bold text-red-500 mb-2">8.5</div>
              <div className="text-slate-300 text-sm">H-Index</div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="testimonios" className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <Badge className="mb-4 bg-red-100 text-red-700 hover:bg-red-200">
              Testimonios
            </Badge>
            <h2 className="text-4xl font-bold text-white mb-6">
              Lo que dicen nuestros pacientes
            </h2>
            <p className="text-xl text-slate-300 max-w-3xl mx-auto">
              Experiencias reales de pacientes que han confiado en nuestro enfoque de reconstrucción maxilofacial
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
            <Card className="bg-slate-900 border-slate-700">
              <CardHeader>
                <div className="flex items-center gap-4">
                  <Avatar>
                    <AvatarFallback>MC</AvatarFallback>
                  </Avatar>
                  <div>
                    <h4 className="text-white font-semibold">María Carmen</h4>
                    <div className="flex text-yellow-400">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-current" />
                      ))}
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Quote className="w-8 h-8 text-red-500 mb-4" />
                <p className="text-slate-300 mb-4">
                  "La reconstrucción que realizó el Dr. Olate cambió completamente mi vida.
                  Su técnica y el uso de tecnología 3D fueron impresionantes."
                </p>
                <p className="text-slate-400 text-sm">Reconstrucción mandibular - 2023</p>
              </CardContent>
            </Card>

            <Card className="bg-slate-900 border-slate-700">
              <CardHeader>
                <div className="flex items-center gap-4">
                  <Avatar>
                    <AvatarFallback>JL</AvatarFallback>
                  </Avatar>
                  <div>
                    <h4 className="text-white font-semibold">José Luis</h4>
                    <div className="flex text-yellow-400">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-current" />
                      ))}
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Quote className="w-8 h-8 text-red-500 mb-4" />
                <p className="text-slate-300 mb-4">
                  "El nivel de precisión y cuidado fue excepcional.
                  El Dr. Olate explicó cada paso del proceso y los resultados superaron mis expectativas."
                </p>
                <p className="text-slate-400 text-sm">Cirugía facial compleja - 2024</p>
              </CardContent>
            </Card>

            <Card className="bg-slate-900 border-slate-700">
              <CardHeader>
                <div className="flex items-center gap-4">
                  <Avatar>
                    <AvatarFallback>AR</AvatarFallback>
                  </Avatar>
                  <div>
                    <h4 className="text-white font-semibold">Ana Rosa</h4>
                    <div className="flex text-yellow-400">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-current" />
                      ))}
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Quote className="w-8 h-8 text-red-500 mb-4" />
                <p className="text-slate-300 mb-4">
                  "Profesionalismo y excelencia técnica. La tecnología digital
                  permitió ver los resultados antes de la cirugía. Totalmente recomendado."
                </p>
                <p className="text-slate-400 text-sm">Planificación 3D - 2023</p>
              </CardContent>
            </Card>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold text-red-500 mb-2">500+</div>
              <div className="text-slate-300">Pacientes Atendidos</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-red-500 mb-2">98%</div>
              <div className="text-slate-300">Satisfacción del Paciente</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-red-500 mb-2">15+</div>
              <div className="text-slate-300">Años de Experiencia</div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contacto" className="py-20 px-4 sm:px-6 lg:px-8 bg-slate-800">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <Badge className="mb-4 bg-red-100 text-red-700 hover:bg-red-200">
              Contacto
            </Badge>
            <h2 className="text-4xl font-bold text-white mb-6">
              Agenda tu Consulta
            </h2>
            <p className="text-xl text-slate-300 max-w-3xl mx-auto">
              Estamos aquí para ayudarte. Contacta con nosotros para una consulta personalizada
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div>
              <h3 className="text-2xl font-bold text-white mb-6">Información de Contacto</h3>
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <Phone className="w-6 h-6 text-red-500 mt-1" />
                  <div>
                    <h4 className="text-white font-semibold">Teléfono</h4>
                    <p className="text-slate-300">+56 45 325 4000</p>
                    <p className="text-slate-300">+56 9 8765 4321</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <Mail className="w-6 h-6 text-red-500 mt-1" />
                  <div>
                    <h4 className="text-white font-semibold">Email</h4>
                    <p className="text-slate-300">sergio.olate@medico.cl</p>
                    <p className="text-slate-300">contacto@sergiolate.cl</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <MapPin className="w-6 h-6 text-red-500 mt-1" />
                  <div>
                    <h4 className="text-white font-semibold">Dirección</h4>
                    <p className="text-slate-300">Av. Francisco Salazar 01145</p>
                    <p className="text-slate-300">Temuco, Chile</p>
                  </div>
                </div>
              </div>

              <div className="mt-8 p-6 bg-slate-900 rounded-lg border border-slate-700">
                <h4 className="text-white font-semibold mb-4">Horarios de Atención</h4>
                <div className="space-y-2 text-slate-300">
                  <div className="flex justify-between">
                    <span>Lunes - Viernes</span>
                    <span>9:00 - 18:00</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Sábados</span>
                    <span>9:00 - 13:00</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Domingos</span>
                    <span>Cerrado</span>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <form className="space-y-6" onSubmit={(e) => { e.preventDefault(); alert('Formulario enviado. Nos contactaremos pronto.'); }}>
                <div>
                  <label className="block text-white font-semibold mb-2">Nombre Completo</label>
                  <input
                    type="text"
                    required
                    className="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-lg text-white focus:border-red-500 focus:outline-none"
                    placeholder="Tu nombre completo"
                  />
                </div>
                <div>
                  <label className="block text-white font-semibold mb-2">Email</label>
                  <input
                    type="email"
                    required
                    className="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-lg text-white focus:border-red-500 focus:outline-none"
                    placeholder="tu@email.com"
                  />
                </div>
                <div>
                  <label className="block text-white font-semibold mb-2">Teléfono</label>
                  <input
                    type="tel"
                    required
                    className="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-lg text-white focus:border-red-500 focus:outline-none"
                    placeholder="+56 9 XXXX XXXX"
                  />
                </div>
                <div>
                  <label className="block text-white font-semibold mb-2">Tipo de Consulta</label>
                  <select className="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-lg text-white focus:border-red-500 focus:outline-none">
                    <option>Consulta inicial</option>
                    <option>Reconstrucción maxilofacial</option>
                    <option>Planificación 3D</option>
                    <option>Segunda opinión</option>
                    <option>Seguimiento post-operatorio</option>
                  </select>
                </div>
                <div>
                  <label className="block text-white font-semibold mb-2">Mensaje</label>
                  <textarea
                    rows={4}
                    className="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-lg text-white focus:border-red-500 focus:outline-none"
                    placeholder="Describe tu consulta o necesidad..."
                  ></textarea>
                </div>
                <Button type="submit" className="w-full bg-red-500 hover:bg-red-600 text-white py-3">
                  <Calendar className="w-5 h-5 mr-2" />
                  Enviar Consulta
                </Button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black border-t border-slate-800 py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="col-span-1 md:col-span-2">
              <div className="text-2xl font-bold text-white mb-4">
                Dr. <span className="text-red-500">Sergio Olate</span>
              </div>
              <p className="text-slate-400 mb-4 max-w-md">
                Especialista en reconstrucción maxilofacial con tecnología de vanguardia.
                Devolvemos la función y estética facial con los más altos estándares.
              </p>
              <p className="text-slate-500 text-sm">
                CIRUGÍA MAXILOFACIAL • TECNOLOGÍA DIGITAL • EXCELENCIA MÉDICA
              </p>
            </div>

            <div>
              <h4 className="text-white font-semibold mb-4">Áreas de Especialización</h4>
              <ul className="space-y-2 text-slate-400">
                <li>Planificación Digital 3D</li>
                <li>Reconstrucción Mandibular</li>
                <li>Microcirugía Reconstructiva</li>
                <li>Biomarcadores Quirúrgicos</li>
                <li>Realidad Virtual</li>
              </ul>
            </div>

            <div>
              <h4 className="text-white font-semibold mb-4">Contacto</h4>
              <ul className="space-y-2 text-slate-400">
                <li>+56 45 325 4000</li>
                <li>sergio.olate@medico.cl</li>
                <li>Temuco, Chile</li>
              </ul>
            </div>
          </div>

          <Separator className="my-8 bg-slate-800" />

          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-slate-500 text-sm">
              © 2024 Dr. Sergio Olate. Todos los derechos reservados.
            </p>
            <p className="text-slate-500 text-sm mt-2 md:mt-0">
              Especialista en Reconstrucción Maxilofacial
            </p>
          </div>
        </div>
      </footer>

      {/* Scroll to Top Button */}
      {showScrollTop && (
        <Button
          onClick={scrollToTop}
          className="fixed bottom-8 right-8 bg-red-500 hover:bg-red-600 text-white p-3 rounded-full shadow-lg z-40"
          size="icon"
        >
          <ArrowUp className="w-5 h-5" />
        </Button>
      )}

      {/* JSON-LD Structured Data for SEO */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "Person",
            "name": "Dr. Sergio Olate",
            "jobTitle": "Especialista en Reconstrucción Maxilofacial",
            "image": "https://same-w7qehzskhqv-latest.netlify.app/images/dr-sergio-olate-profesional.jpg",
            "worksFor": {
              "@type": "Organization",
              "name": "Dr. Sergio Olate - Cirugía Maxilofacial"
            },
            "address": {
              "@type": "PostalAddress",
              "streetAddress": "Av. Francisco Salazar 01145",
              "addressLocality": "Temuco",
              "addressCountry": "CL"
            },
            "telephone": "+56 45 325 4000",
            "email": "sergio.olate@medico.cl",
            "url": "https://same-w7qehzskhqv-latest.netlify.app",
            "sameAs": [],
            "knowsAbout": [
              "Cirugía Maxilofacial",
              "Reconstrucción Facial",
              "Planificación Digital 3D",
              "Microcirugía"
            ]
          })
        }}
      />
    </div>
  );
}
